from flask import Flask, request, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import os
from werkzeug.security import generate_password_hash, check_password_hash
from contextlib import contextmanager

app = Flask(__name__)

app.secret_key = os.environ.get('SECRET_KEY', 'default_secret_key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sport_items.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class SportItems(db.Model):
    __tablename__ = 'sport_items'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    condition = db.Column(db.String(100), nullable=False)

    def __init__(self, name, quantity, condition):
        self.name = name
        self.quantity = quantity
        self.condition = condition

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    surname = db.Column(db.String(50), nullable=False)
    login = db.Column(db.String(50), unique=True, nullable=False)
    phone = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(1024), nullable=False)

    def __init__(self, name, surname, login, phone, email, password):
        self.name = name
        self.surname = surname
        self.login = login
        self.phone = phone
        self.email = email
        self.password_hash = generate_password_hash(password)

@app.route("/")
def index():
    return redirect(url_for('enter'))

@app.route("/registration", methods=['GET', 'POST'])
def registration():
    if request.method == 'POST':
        name = request.form.get('name')
        surname = request.form.get('surname')
        login = request.form.get('login')
        phone = request.form.get('phone')
        email = request.form.get('email')
        password = request.form.get('password')

        if not all([name, surname, login, phone, email, password]):
            flash("All fields are required.", "error")
            return render_template("registration.html")

        if User.query.filter_by(email=email).first():
            flash("Email already registered.", "error")
            return render_template("registration.html")
        
        if User.query.filter_by(login=login).first():
            flash("Login already taken.", "error")
            return render_template("registration.html")

        new_user = User(name=name, surname=surname, login=login,
                        phone=phone, email=email, password=password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for("enter"))
        except Exception as e:
            db.session.rollback()
            flash(f"An error occurred while registering the user: {str(e)}", "error")

    return render_template("registration.html")

@app.route("/login", methods=['GET', 'POST'])
def enter():
    if request.method == 'POST':
        login = request.form.get('login')
        password = request.form.get('password')

        if not login or not password:
            flash("Login and password are required.", "error")
            return render_template("enter.html")

        if login == 'admin' and password == 'admin':
            return render_template("admin.html")
        
        user = User.query.filter_by(login=login).first()
        
        if user and check_password_hash(user.password_hash, password):
            flash("Login successful!", "success")
            return redirect(url_for("main_page"))
        else:
            flash("Invalid login or password.", "error")

    return render_template("enter.html")

@app.route("/main")
def main_page():
    return render_template("main.html")

@contextmanager
def session_scope():
    """Provide a transactional scope around a series of operations."""
    try:
        yield db.session
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        raise
    finally:
        db.session.close()

@app.route("/admin", methods=['GET', 'POST'])
def account():
    if request.method == 'POST':
        name = request.form.get('name')
        quantity = request.form.get('quantity')
        condition = request.form.get('condition')

        if not all([name, quantity, condition]):
            flash('All fields are required!', 'error')
            return redirect(url_for('account'))

        new_item = SportItems(name=name, quantity=quantity, condition=condition)
        db.session.add(new_item)
        db.session.flush()
        db.session.commit()

    return render_template("admin.html")

if __name__ == '__main__':
    with app.app_context():
        if not os.path.exists(app.instance_path):
            os.makedirs(app.instance_path)
        
        db.create_all()

    app.run(port=8080, host='127.0.0.1', debug=True)