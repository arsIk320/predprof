from flask import Flask, request, render_template, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
import os
import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your_secret_key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///inventory.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Items(db.Model):
    __tablename__ = 'items'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    condition = db.Column(db.String(100), nullable=False)

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    login = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(1024), nullable=False)

class Applications(db.Model):
    __tablename__ = 'applications'
    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(50), default="New")
    date = db.Column(db.DateTime, default=datetime.datetime.utcnow)

class InventoryLog(db.Model):
    __tablename__ = 'inventory_log'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    item_id = db.Column(db.Integer, nullable=False)
    borrow_date = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    return_date = db.Column(db.DateTime, nullable=True)

@app.route("/main", methods=['GET', 'POST'])
def main_page():
    items = Items.query.all()

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'borrow':
            item_id = request.form.get('item_id')
            quantity = int(request.form.get('quantity'))
            item = Items.query.get(item_id)

            if item and item.quantity >= quantity and item.status == "Available":
                new_application = Applications(item_id=item_id, quantity=quantity)
                item.quantity -= quantity
                if item.quantity == 0:
                    item.status = "Occupied"  # Изменение статуса на "занят" только если количество равно 0
                log_entry = InventoryLog(user_id=session.get('user_id'), item_id=item_id)  # Запись о взятии
                db.session.add(new_application)
                db.session.add(log_entry)
                db.session.commit()
                flash('Item borrowed successfully!', 'success')
            else:
                flash('Item is not available or insufficient quantity.', 'error')

        elif action == 'return':
            log_id = request.form.get('log_id')
            log_entry = InventoryLog.query.get(log_id)

            if log_entry:
                item = Items.query.get(log_entry.item_id)
                item.quantity += log_entry.quantity
                if item.quantity > 0:
                    item.status = "Available"  # Изменение статуса на "доступен" только если количество больше 0
                log_entry.return_date = datetime.datetime.utcnow()
                db.session.commit()
                flash('Item returned successfully!', 'success')
            else:
                flash('Invalid return entry.', 'error')
        return redirect(url_for('main_page'))

    inventory_logs = InventoryLog.query.filter_by(return_date=None).all()  # Получаем только незавершенные записи
    return render_template("main.html", items=items, inventory_logs=inventory_logs)

@app.route("/admin", methods=['GET', 'POST'])
def admin():
    applications = Applications.query.all()

    if request.method == 'POST':
        application_id = request.form.get('application_id')
        action = request.form.get('action')
        application = Applications.query.get(application_id)

        if action == 'accept':
            item = Items.query.get(application.item_id)
            if item.quantity >= application.quantity:
                item.quantity -= application.quantity
                application.status = 'Accepted'
                if item.quantity == 0:
                    item.status = "Occupied"  # Изменение статуса на "занят" только если количество равно 0
                db.session.delete(application)  # Удаляем заявку после принятия
                db.session.commit()
                flash('Application accepted!', 'success')
            else:
                flash('Insufficient item quantity to accept application.', 'error')

        elif action == 'reject':
            application.status = 'Rejected'
            db.session.delete(application)  # Удаляем заявку после отклонения
            db.session.commit()
            flash('Application rejected!', 'success')

        return redirect(url_for('admin'))

    return render_template("admin.html", applications=applications)


if __name__ == '__main__':
    with app.app_context():
        if not os.path.exists(app.instance_path):
            os.makedirs(app.instance_path)
        db.create_all()
    app.run(port=8080, host='127.0.0.1', debug=True)
