document.addEventListener('DOMContentLoaded', () => {
    const navButtons = document.querySelectorAll('header nav button');
    const pages = document.querySelectorAll('main.html')
    const overlay = document.getElementById('overlay');
  
    // Инвентарь
    const inventoryList = document.getElementById('inventory-list');
  
    // Заявки
    const addRequestButton = document.getElementById('add-request-button');
    const requestForm = document.getElementById('request-form');
    const requestList = document.getElementById('request-list');
    const requestEditForm = document.getElementById('request-edit-form');
  
    // Закрытие модальных окон
    const closeButtons = document.querySelectorAll('.close-button');
  
    let inventory = [];
    let requests = [];
    let currentRequestId = null;
  
  
      // Функция для скрытия всех страниц и деактивации кнопок
      const hideAllPages = () => {
          pages.forEach(page => page.classList.add('hidden'));
      };
      const deactivateAllNavButtons = () => {
          navButtons.forEach(button => button.classList.remove('active'));
      };
  
      // Функция для отображения нужной страницы и активации соответствующей кнопки
    const showPage = (pageId) => {
          hideAllPages();
          const page = document.getElementById(pageId + '-page');
          if (page) {
              page.classList.remove('hidden');
          }
  
          deactivateAllNavButtons();
          const button = document.querySelector(`header nav button[data-page="${pageId}"]`);
          if (button) {
              button.classList.add('active');
          }
      };
  
      // Обработчики кликов для кнопок навигации
      navButtons.forEach(button => {
        button.addEventListener('click', () => {
            const pageId = button.getAttribute('data-page');
            showPage(pageId);
        });
      });
  
    //  Модалки
    const showModal = (modal) => {
      overlay.classList.remove('hidden');
      modal.classList.remove('hidden');
    };
    const hideModal = (modal) => {
      overlay.classList.add('hidden');
      modal.classList.add('hidden');
      requestEditForm.reset();
      currentRequestId = null;
    };
    closeButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        const modal = e.target.closest('.modal');
        hideModal(modal);
      });
    });
    overlay.addEventListener('click', () => {
      const modals = document.querySelectorAll('.modal');
      modals.forEach(modal => {
        hideModal(modal);
      });
    });
  
    // ----------------- DATA FETCHING ----------------- //
  
    const fetchInventory = async () => {
      // Заглушка для запроса данных (заменить на реальный запрос к API)
        // В будущем тут будет axios.get('/api/inventory')
        return new Promise(resolve => {
           setTimeout(() => {
                resolve([]); // Пустой массив по умолчанию
           }, 200);
       });
    };
  
    // ----------------- INVENTORY FUNCTIONALITY ----------------- //
  
    const renderInventoryList = () => {
      inventoryList.innerHTML = '';
      inventory.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('inventory-item');
        itemElement.innerHTML = `
                   <h3>${item.name}</h3>
                   <p>Количество: ${item.quantity}</p>
                  <p>Состояние: ${item.state}</p>
            `;
        inventoryList.appendChild(itemElement);
      });
    };
  
    // ----------------- REQUESTS FUNCTIONALITY ----------------- //
  
    addRequestButton.addEventListener('click', () => {
      showModal(requestForm);
      const inventorySelect = document.getElementById('request-inventory');
      inventorySelect.innerHTML = '';
      inventory.forEach(item => {
        const option = document.createElement('option');
        option.value = item.id;
          option.textContent = `${item.name} (Доступно: ${item.quantity})`;
        inventorySelect.appendChild(option);
      });
    });
  
    requestEditForm.addEventListener('submit', (e) => {
      e.preventDefault();
        const description = document.getElementById('request-description').value;
        const inventoryId =  parseInt(document.getElementById('request-inventory').value);
        const quantity = parseInt(document.getElementById('request-quantity').value);
        const inventoryItem =  inventory.find(item => item.id === inventoryId)
  
      if (currentRequestId) {
        const updatedRequests = requests.map(request => {
          if (request.id === currentRequestId) {
            return { ...request, inventoryId, quantity, itemName: inventoryItem?.name, state: inventoryItem?.state, description };
          }
          return request;
        });
        requests = updatedRequests;
      } else {
          const newRequest = {
              id: Date.now(),
            inventoryId,
             quantity,
            itemName: inventoryItem?.name,
              state: inventoryItem?.state,
           description,
             status: 'Новая'
         };
        requests.push(newRequest);
      }
      renderRequestList();
      hideModal(requestForm);
    });
  
      const renderRequestList = () => {
          requestList.innerHTML = '';
        requests.forEach(request => {
          const requestElement = document.createElement('div');
          requestElement.classList.add('request-item');
          requestElement.innerHTML = `
                  <p>Описание: ${request.description}</p>
                 <p>Инвентарь: ${request.itemName}</p>
                 <p>Состояние: ${request.state}</p>
                 <p>Количество: ${request.quantity}</p>
                 <p>Статус: ${request.status}</p>
                  <button class="edit-request-item" data-id="${request.id}">Редактировать</button>
                 <button class="delete-request-item" data-id="${request.id}">Удалить</button>
            `;
          requestList.appendChild(requestElement);
       });
          requestList.querySelectorAll('.edit-request-item').forEach(button => {
            button.addEventListener('click', (e) => {
              const requestId = parseInt(e.target.getAttribute('data-id'));
              currentRequestId = requestId;
              const currentRequest = requests.find(request => request.id === requestId);
              document.getElementById('request-description').value = currentRequest.description;
               document.getElementById('request-inventory').value = currentRequest.inventoryId
                document.getElementById('request-quantity').value = currentRequest.quantity;
              showModal(requestForm);
            });
          });
          requestList.querySelectorAll('.delete-request-item').forEach(button => {
             button.addEventListener('click', (e) => {
                  const requestId = parseInt(e.target.getAttribute('data-id'));
               requests = requests.filter(request => request.id !== requestId);
              renderRequestList();
              });
           });
      };
  
  
  
      const initialize = async () => {
          inventory = await fetchInventory();
          renderInventoryList();
         showPage('inventory');
      };
      initialize();
  });