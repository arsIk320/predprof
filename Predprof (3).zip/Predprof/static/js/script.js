document.addEventListener('DOMContentLoaded', () => {
    const navButtons = document.querySelectorAll('header nav button');
    const pages = document.querySelectorAll('main .page');
    const overlay = document.getElementById('overlay');

     // Инвентарь
    const addInventoryButton = document.getElementById('add-inventory-button');
    const inventoryForm = document.getElementById('inventory-form');
     const inventoryList = document.getElementById('inventory-list');
     const inventoryEditForm = document.getElementById('inventory-edit-form');

     // Пользователи
     const addUserButton = document.getElementById('add-user-button');
     const userForm = document.getElementById('user-form');
     const userList = document.getElementById('user-list');
     const userEditForm = document.getElementById('user-edit-form');

     // Закупки
     const addPurchaseButton = document.getElementById('add-purchase-button');
      const purchaseForm = document.getElementById('purchase-form');
     const purchaseList = document.getElementById('purchase-list');
     const purchaseEditForm = document.getElementById('purchase-edit-form');


    // Отчеты
    const generateReportButton = document.getElementById('generate-report-button')
     const reportsContent = document.getElementById('reports-content');

    // Заявки
    const requestsPage = document.getElementById('requests-page');
    const requestsList = document.getElementById('requests-list');


     // Закрытие модальных окон
    const closeButtons = document.querySelectorAll('.close-button');

    let currentInventoryId = null;
     let currentUserId = null;
     let currentPurchaseId = null;
    let inventory = [];
    let users = [];
    let purchases = [];
    let requests = [];

    // Функция для скрытия всех страниц и деактивации кнопок
     const hideAllPages = () => {
         pages.forEach(page => page.classList.add('hidden'));
     };
    const deactivateAllNavButtons = () => {
         navButtons.forEach(button => button.classList.remove('active'));
    }


    // Функция для отображения нужной страницы и активации соответствующей кнопки
   const showPage = (pageId) => {
       hideAllPages();
        const page = document.getElementById(pageId + '-page');
        if(page){
           page.classList.remove('hidden');
        }


      deactivateAllNavButtons()
      const button = document.querySelector(`header nav button[data-page="${pageId}"]`)
      if(button){
        button.classList.add('active')
      }

    };

    // Обработчики кликов для кнопок навигации
    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            const pageId = button.getAttribute('data-page');
            showPage(pageId);
        });
    });

  //  Модалки
     const showModal = (modal) => {
         overlay.classList.remove('hidden');
         modal.classList.remove('hidden');
     };
     const hideModal = (modal) => {
         overlay.classList.add('hidden');
         modal.classList.add('hidden');
        inventoryEditForm.reset();
        userEditForm.reset();
       purchaseEditForm.reset();
        currentInventoryId = null;
       currentUserId = null;
       currentPurchaseId = null;

     };

      closeButtons.forEach(button => {
         button.addEventListener('click', (e) => {
          const modal =  e.target.closest('.modal');
             hideModal(modal);
         });
      });

       overlay.addEventListener('click', () => {
        const modals =  document.querySelectorAll('.modal');
        modals.forEach(modal => {
             hideModal(modal)
        })
      });


    addInventoryButton.addEventListener('click', () => {
        showModal(inventoryForm);
    });


    inventoryEditForm.addEventListener('submit', (e) => {
      e.preventDefault();
       const name = document.getElementById('inventory-name').value;
        const quantity = document.getElementById('inventory-quantity').value;
        const state = document.getElementById('inventory-state').value;

        if(currentInventoryId) {
            const updatedInventory = inventory.map(item => {
                if(item.id === currentInventoryId) {
                  return {...item, name, quantity, state}
                }
                return item
            });
              inventory = updatedInventory
        } else {
          const newItem = {
                id: Date.now(),
                name,
                 quantity: parseInt(quantity),
                state
          }
         inventory.push(newItem);
          addRequest('Добавлен инвентарь', newItem.name)
        }

        renderInventoryList();
        hideModal(inventoryForm);
    });

  const  renderInventoryList = () => {
         inventoryList.innerHTML = '';
        inventory.forEach(item => {
             const itemElement = document.createElement('div');
            itemElement.classList.add('inventory-item');
            itemElement.innerHTML = `
                <h3>${item.name}</h3>
                <p>Количество: ${item.quantity}</p>
                <p>Состояние: ${item.state}</p>
                <button class="edit-inventory-item action-button" data-id="${item.id}">Редактировать</button>
                <button class="delete-inventory-item action-button" data-id="${item.id}">Удалить</button>
             `;
            inventoryList.appendChild(itemElement);
        })

      inventoryList.querySelectorAll('.edit-inventory-item').forEach(button => {
        button.addEventListener('click', (e) => {
          const inventoryId = parseInt(e.target.getAttribute('data-id'));
          currentInventoryId = inventoryId;

            const currentItem = inventory.find(item => item.id === inventoryId);

             document.getElementById('inventory-name').value = currentItem.name;
            document.getElementById('inventory-quantity').value = currentItem.quantity;
            document.getElementById('inventory-state').value = currentItem.state;


             showModal(inventoryForm)
        })
      })

         inventoryList.querySelectorAll('.delete-inventory-item').forEach(button => {
           button.addEventListener('click', (e) => {
                const inventoryId = parseInt(e.target.getAttribute('data-id'));
             inventory = inventory.filter(item => item.id !== inventoryId);
             addRequest('Удален инвентарь', item.name)
              renderInventoryList();
           })
        })
  };

  // ----------------- USERS FUNCTIONALITY ----------------- //
  addUserButton.addEventListener('click', () => {
    showModal(userForm);
     const inventorySelect = document.getElementById('user-inventory')
    inventorySelect.innerHTML = '';
       inventory.forEach(item => {
        const option = document.createElement('option');
        option.value = item.id;
        option.textContent = item.name;
        inventorySelect.appendChild(option);
      })
   });


  userEditForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('user-name').value;
    const inventoryIds = Array.from(document.getElementById('user-inventory').selectedOptions).map(option => parseInt(option.value));

        if(currentUserId) {
            const updatedUsers = users.map(user => {
                if(user.id === currentUserId) {
                  return {...user, name, inventoryIds}
                }
                return user
            });
              users = updatedUsers
        } else {
          const newUser = {
                id: Date.now(),
                name,
              inventoryIds
          }
          users.push(newUser);
           addRequest('Добавлен пользователь', newUser.name)
        }

    renderUserList();
    hideModal(userForm);
});

    const  renderUserList = () => {
         userList.innerHTML = '';
       users.forEach(user => {
            const userElement = document.createElement('div');
           userElement.classList.add('user-item');
            const assignedInventoryNames = user.inventoryIds
            .map(id => {
                const inv =  inventory.find(inv => inv.id === id)
                return inv?.name || ''
            }).filter(Boolean).join(', ')

           userElement.innerHTML = `
               <h3>${user.name}</h3>
               <p>Инвентарь: ${assignedInventoryNames}</p>
                <button class="edit-user-item action-button" data-id="${user.id}">Редактировать</button>
                <button class="delete-user-item action-button" data-id="${user.id}">Удалить</button>
             `;
            userList.appendChild(userElement);
        })

       userList.querySelectorAll('.edit-user-item').forEach(button => {
         button.addEventListener('click', (e) => {
              const userId = parseInt(e.target.getAttribute('data-id'));
              currentUserId = userId;

            const currentUser = users.find(user => user.id === userId);

              document.getElementById('user-name').value = currentUser.name;

                const inventorySelect = document.getElementById('user-inventory')
                 Array.from(inventorySelect.options).forEach(option => {
                     option.selected = currentUser.inventoryIds.includes(parseInt(option.value))
                 })

            showModal(userForm)
         })
        })

        userList.querySelectorAll('.delete-user-item').forEach(button => {
           button.addEventListener('click', (e) => {
                 const userId = parseInt(e.target.getAttribute('data-id'));
               users = users.filter(user => user.id !== userId);
             addRequest('Удален пользователь', user.name)
             renderUserList();
           })
        })
    };

   // ----------------- PURCHASES FUNCTIONALITY ----------------- //

  addPurchaseButton.addEventListener('click', () => {
      showModal(purchaseForm)
  })

  purchaseEditForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('purchase-name').value;
        const price = document.getElementById('purchase-price').value;
       const quantity = document.getElementById('purchase-quantity').value;
      const supplier = document.getElementById('purchase-supplier').value;
         const purchaseDate = document.getElementById('purchase-date').value;


         if(currentPurchaseId) {
            const updatedPurchases = purchases.map(purchase => {
                if(purchase.id === currentPurchaseId) {
                    return {...purchase, name, price, quantity, supplier, purchaseDate}
                }
                return purchase
            });
              purchases = updatedPurchases
        } else {
            const newPurchase = {
                id: Date.now(),
                name,
                price: parseInt(price),
                 quantity: parseInt(quantity),
                supplier,
                 purchaseDate
            }
             purchases.push(newPurchase);
             addRequest('Добавлена закупка', newPurchase.name)
         }
          renderPurchaseList();
         hideModal(purchaseForm);
    });

    const  renderPurchaseList = () => {
       purchaseList.innerHTML = '';
      purchases.forEach(purchase => {
           const purchaseElement = document.createElement('div');
           purchaseElement.classList.add('purchase-item');
           purchaseElement.innerHTML = `
               <h3>${purchase.name}</h3>
               <p>Цена: ${purchase.price}</p>
              <p>Количество: ${purchase.quantity}</p>
                <p>Поставщик: ${purchase.supplier}</p>
                <p>Дата поставки: ${purchase.purchaseDate}</p>
                 <button class="edit-purchase-item action-button" data-id="${purchase.id}">Редактировать</button>
                <button class="delete-purchase-item action-button" data-id="${purchase.id}">Удалить</button>
            `;
          purchaseList.appendChild(purchaseElement);
       })


       purchaseList.querySelectorAll('.edit-purchase-item').forEach(button => {
         button.addEventListener('click', (e) => {
             const purchaseId = parseInt(e.target.getAttribute('data-id'));
              currentPurchaseId = purchaseId;

            const currentPurchase = purchases.find(purchase => purchase.id === purchaseId);
             document.getElementById('purchase-name').value = currentPurchase.name;
               document.getElementById('purchase-price').value = currentPurchase.price;
            document.getElementById('purchase-quantity').value = currentPurchase.quantity;
                document.getElementById('purchase-supplier').value = currentPurchase.supplier;
               document.getElementById('purchase-date').value = currentPurchase.purchaseDate;


             showModal(purchaseForm)
         })
        })

      purchaseList.querySelectorAll('.delete-purchase-item').forEach(button => {
        button.addEventListener('click', (e) => {
             const purchaseId = parseInt(e.target.getAttribute('data-id'));
           purchases = purchases.filter(purchase => purchase.id !== purchaseId);
           addRequest('Удалена закупка', purchase.name)
           renderPurchaseList();
         })
       })

  };


    // ----------------- REPORTS FUNCTIONALITY ----------------- //

    generateReportButton.addEventListener('click', () => {
       let reportHtml = '<h3>Отчет по инвентарю:</h3>';
       inventory.forEach(item => {
           reportHtml += `
               <p>${item.name}: Количество - ${item.quantity}, Состояние - ${item.state}</p>
            `;
        })

         reportHtml += '<h3>Отчет по закупкам:</h3>';

       purchases.forEach(purchase => {
           reportHtml += `
              <p>Наименование: ${purchase.name}, Цена: ${purchase.price}, Количество: ${purchase.quantity}, Поставщик: ${purchase.supplier}, Дата: ${purchase.purchaseDate}</p>
            `
        })
         reportsContent.innerHTML = reportHtml;
   })


    const renderRequestsList = () => {
        requestsList.innerHTML = '';
       requests.forEach(request => {
            const requestElement = document.createElement('div');
             requestElement.classList.add('request-item')
            requestElement.innerHTML = `
                <p><b>Тип:</b> ${request.type}, <b>Название</b>: ${request.name}</p>
            `;
          requestsList.appendChild(requestElement);
        });
    }

    const addRequest = (type, name) => {
      const newRequest = {
        id: Date.now(),
        type,
        name
      };
        requests.push(newRequest);
      renderRequestsList()
    }



    // Initial load - show the inventory page
     showPage('inventory')
});